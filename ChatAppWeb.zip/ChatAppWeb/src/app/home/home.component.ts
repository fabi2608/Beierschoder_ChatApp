import { Component, OnInit } from '@angular/core';
import { ChatService } from '../services/chat.service';
import { Message } from '../models/message.model';
import { AuthService } from '../auth.service';
import { UserService } from '../services/user.service';
import { Chat } from '../models/chat.model';
import { ObjectId } from 'bson';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{
  loggedInUser: string = '';
  targetUsername: string = '';
  chatHistory: Message[] = [];
  messageText: string = '';
  chatList: Chat[] = [];
  currentChatPartner: string = '';
  showUserOptions: boolean = false;
  chatId: string = '';

  constructor(private chatService: ChatService, private authService: AuthService, private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.loggedInUser = this.authService.getCurrentUser() ?? '';
    this.loadChats();
  }

  onChatCreated(chat: Chat): void {
    this.addChatToList(chat);
    const chatPartner = chat.participants.find(p => p !== this.loggedInUser) ?? '';
    this.loadChatHistory(this.loggedInUser, chatPartner);
    this.currentChatPartner = chatPartner;
    this.chatId = chat.id;
  }

  onChatSelected(chat: Chat): void {
    this.targetUsername = chat.participants.find(p => p !== this.loggedInUser) ?? '';
    this.currentChatPartner = this.targetUsername;
    this.chatId = chat.id;
    this.loadChatHistory(this.loggedInUser, this.targetUsername);
  }

  loadChats(): void {
    this.chatService.getChatsForUser(this.loggedInUser).subscribe(
      (chats: Chat[]) => {
        this.chatList = chats;
      },
      (error) => {
        console.error('Error loading chats:', error);
      }
    );
  }

  addChatToList(chat: Chat): void {
    if (!this.chatList.find(c => c.id === chat.id)) {
      this.chatList.push(chat);
    }
  }

  loadChatHistory(username: string, username2: string): void {
    this.chatService.getChatHistory(username, username2).subscribe(
      (history: Message[]) => {
        console.log('Chat history loaded:', history);
        this.chatHistory = history;
        this.chatHistory.forEach(message => {
          if (isNaN(message.timeStamp.getTime())) {
            console.error('Invalid date found:', message.timeStamp);
          }
        });
      },
      (error) => {
        console.error('Error loading chat history:', error);
      }
    );
  }
  

  createNewChat(targetUsername: string): void {
    const newChat: Chat = {
      id: new ObjectId().toHexString(),
      participants: [this.loggedInUser, targetUsername],
      messages: []
    };

    this.chatService.createChat(newChat).subscribe(
      (createdChat: Chat) => {
        this.onChatCreated(createdChat);
      },
      (error) => {
        console.error('Error creating chat:', error);
      }
    );
  }

  sendMessage(): void {
    if (this.messageText.trim() !== '') {
      const newMessage: Message = {
        id: new ObjectId().toHexString(),
        author: this.loggedInUser,
        text: this.messageText,
        timeStamp: new Date()
      };

      this.chatService.sendMessage(this.loggedInUser, this.targetUsername, newMessage).subscribe(
        () => {
          this.messageText = '';
          this.chatHistory.push(newMessage);
        },
        (error) => {
          console.error('Error sending message:', error);
        }
      );
    }
  }

  onSearchUserSelected(username: string): void {
    this.targetUsername = username;
    this.createNewChat(username);
  }

  toggleUserOptions() {
    this.showUserOptions = !this.showUserOptions;
  }

  logout() {
    this.loggedInUser = '';
    this.router.navigate(['/login']);
    console.log('Logging out...');
  }

  deleteAccount() {
    const confirmation = confirm("Are you sure you want to delete your account?");
    if (confirmation) {
      this.userService.deleteUser(this.loggedInUser).subscribe(
        (response: any) => {
          console.log(response.message);
          this.logout();
        },
        (error) => {
          console.error('Error deleting account:', error);
        }
      );
    }
  }
}
