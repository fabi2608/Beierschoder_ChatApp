import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user.model';
import { Chat } from '../../models/chat.model';
import { ChatService } from '../../services/chat.service';
import { AuthService } from '../../auth.service';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.css']
})
export class SearchBarComponent implements OnInit {
  @Output() chatCreated: EventEmitter<Chat> = new EventEmitter<Chat>();
  searchQuery: string = '';
  searchResults: User[] = [];
  loggedInUser: string = '';

  constructor(
    private userService: UserService,
    private chatService: ChatService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loggedInUser = this.authService.getCurrentUser() ?? '';
  }

  search(): void {
    if (this.searchQuery.trim() !== '') {
      this.userService.searchUsers(this.searchQuery).subscribe(
        (results: User[]) => {
          // Filter out the logged-in user from the search results
          this.searchResults = results.filter(user => user.username !== this.loggedInUser);
        },
        (error) => {
          console.error('Error searching users:', error);
        }
      );
    } else {
      this.searchResults = [];
    }
  }

  openChat(user: User): void {
    
    this.searchResults = [];

    this.chatService.getChatWithUser(user.username).subscribe(
      (chat: Chat | null) => {
        if (chat) {
          this.chatCreated.emit(chat);
        } else {
          const newChat: Chat = {
            id: uuidv4(),
            participants: [this.loggedInUser, user.username],
            messages: []
          };
          this.chatService.createChat(newChat).subscribe(
            () => {
              console.log('New chat created with user:', user.username);
              this.chatCreated.emit(newChat);
            },
            (error) => {
              console.error('Error creating new chat:', error);
            }
          );
        }
      },
      (error) => {
        console.error('Error getting chat with user:', error);
      }
    );
  }
}