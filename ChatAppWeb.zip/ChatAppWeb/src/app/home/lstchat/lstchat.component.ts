// lstchat.component.ts
import { Component, Input } from '@angular/core';
import { Chat } from '../../models/chat.model';
import { Message } from '../../models/message.model';
import { ChatService } from '../../services/chat.service';
import { AuthService } from '../../auth.service';
import { v4 as uuidv4 } from 'uuid';

@Component({
  selector: 'app-lstchat',
  templateUrl: './lstchat.component.html',
  styleUrls: ['./lstchat.component.css']
})
export class LstChatComponent {
  @Input() chatHistory: Message[] = [];
  @Input() targetUsername: string = '';
  @Input() loggedInUser: string = '';
  @Input() chatId: string = '';
 
  messageText: string = '';

  constructor(private chatService: ChatService, private authService: AuthService) {}

  ngOnInit(): void {
    this.loggedInUser = this.authService.getCurrentUser() ?? '';
  }
  sendMessage(): void {
    if (this.messageText.trim() !== '') {
      const newMessage: Message = {
        id: uuidv4(),
        author: this.loggedInUser,
        text: this.messageText,
        timeStamp: new Date()
      };

      this.chatService.sendMessage(this.loggedInUser, this.targetUsername, newMessage).subscribe(
        (response) => {
          this.messageText = '';
          this.chatHistory.push(newMessage);
        },
        (error) => {
          console.error('Error sending message:', error);
        }
      );
    }
  }

  deleteMessage(chatId: string, messageId: string): void {
    this.chatService.deleteMessage(chatId, messageId).subscribe(
      () => {
        this.chatHistory = this.chatHistory.filter(message => message.id !== messageId);
      },
      (error) => {
        console.error('Error deleting message:', error);
      }
    );
  }

}