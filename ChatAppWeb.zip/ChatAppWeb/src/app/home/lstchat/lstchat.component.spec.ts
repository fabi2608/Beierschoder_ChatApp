import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LstchatComponent } from './lstchat.component';

describe('LstchatComponent', () => {
  let component: LstchatComponent;
  let fixture: ComponentFixture<LstchatComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LstchatComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LstchatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
