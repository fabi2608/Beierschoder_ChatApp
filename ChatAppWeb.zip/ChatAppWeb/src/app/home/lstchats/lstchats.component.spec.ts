import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LstchatsComponent } from './lstchats.component';

describe('LstchatsComponent', () => {
  let component: LstchatsComponent;
  let fixture: ComponentFixture<LstchatsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LstchatsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LstchatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
