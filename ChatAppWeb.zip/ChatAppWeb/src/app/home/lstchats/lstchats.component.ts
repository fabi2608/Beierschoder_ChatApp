import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ChatService } from '../../services/chat.service';
import { AuthService } from '../../auth.service';
import { Chat } from '../../models/chat.model';

@Component({
  selector: 'app-lstchats',
  templateUrl: './lstchats.component.html',
  styleUrls: ['./lstchats.component.css']
})
export class LstChatsComponent implements OnInit {
  @Input() chatList: Chat[] = [];
  @Input() newChat: Chat | null = null;
  @Output() chatSelected: EventEmitter<Chat> = new EventEmitter<Chat>();
  chats: Chat[] = [];
  currentUser: string = '';

  constructor(private chatService: ChatService, private authService: AuthService) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser() ?? '';
  }

  loadChatsForUser(username: string): void {
    this.chatService.getChatsForUser(username).subscribe(
      (chats: Chat[]) => {
        this.chats = chats;
      },
      (error) => {
        console.error('Error loading chats:', error);
      }
    );
  }

  selectChat(chat: Chat): void {
    this.chatSelected.emit(chat);
  }

  getChatPartnerName(chat: Chat): string {
    const chatPartner = chat.participants.find(participant => participant !== this.currentUser);
    return chatPartner ? chatPartner : 'Unknown';
  }
}
