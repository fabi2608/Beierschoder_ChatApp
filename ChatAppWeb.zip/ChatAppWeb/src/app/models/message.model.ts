import { ObjectId } from 'bson';

export interface Message {
  id: string;
  text: string;
  author: string;
  timeStamp: Date;
}

export class Message implements Message {
  constructor(
    public id: string = new ObjectId().toHexString(),
    public text: string = '',
    public author: string = '',
    public timeStamp: Date = new Date()
  ) {}
}