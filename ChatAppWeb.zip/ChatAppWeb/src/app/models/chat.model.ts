// chat.model.ts
import { ObjectId } from 'bson';
import { Message } from './message.model';

export interface Chat {
  id: string;
  participants: string[];
  messages: Message[];
}

export class Chat implements Chat {
  constructor(
    public id: string = new ObjectId().toHexString(),
    public participants: string[] = [],
    public messages: Message[] = []
  ) {}
}