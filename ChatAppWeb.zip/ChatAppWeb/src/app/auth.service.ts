import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private loggedInUser: string | null = null;
  private apiUrl = 'https://localhost:7037/api/User';

  constructor(private http: HttpClient) { }

  async login(username: string, password: string): Promise<boolean> {
    try {
      const response = await this.http.post<any>(`${this.apiUrl}/login`, { username, password }).toPromise();
      this.loggedInUser = username;
      console.info('Anmeldung erfolgreich');
      return true;
    } catch (error) {
      console.error('Anmeldefehler:', error);
      return false;
    }
  }


  async register(username: string, password: string): Promise<boolean> {
    try {
      const response = await this.http.post<any>(this.apiUrl, { username, password }).toPromise();
      this.loggedInUser = username;
      console.info('Registrierung erfolgreich');
      return true;
    } catch (error) {
      console.error('Registrierungsfehler:', error);
      return false;
    }
  }

  getCurrentUser(): string | null {
    return this.loggedInUser;
  }
}
