import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { SearchBarComponent } from './home/searchbar/searchbar.component';
import { LstChatsComponent } from './home/lstchats/lstchats.component';
import { LstChatComponent } from './home/lstchat/lstchat.component';
import { UserService } from './services/user.service';
import { ChatService } from './services/chat.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    SearchBarComponent,
    LstChatsComponent,
    LstChatComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [UserService, ChatService],
  bootstrap: [AppComponent]
})
export class AppModule { }