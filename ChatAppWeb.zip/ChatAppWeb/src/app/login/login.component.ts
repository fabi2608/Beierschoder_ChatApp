import { Component } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}
  
  async login() {
    const success = await this.authService.login(this.username, this.password);
    if (success) {
      this.router.navigate(['/home']);
    } else {
      this.errorMessage = 'Anmeldung fehlgeschlagen. Überprüfen Sie Benutzername und Passwort.';
    }
  }

  async register() {
    const success = await this.authService.register(this.username, this.password);
    if (success) {
      this.router.navigate(['/home']);
    } 
    if (!success) {
      this.errorMessage = 'Registrierung fehlgeschlagen. Bitte versuchen Sie es erneut.';
    }
  }

}
