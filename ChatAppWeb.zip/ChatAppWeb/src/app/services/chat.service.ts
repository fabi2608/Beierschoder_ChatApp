import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Chat } from '../models/chat.model';
import { Message } from '../models/message.model';
import { catchError, map, switchMap } from 'rxjs/operators';
import { ObjectId } from 'bson';
@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private readonly baseUrl = 'https://localhost:7037/api/Chat';

  constructor(private http: HttpClient) {}

  getChatsForUser(username: string): Observable<Chat[]> {
    return this.http.get<Chat[]>(`${this.baseUrl}/User/${username}`);
  }

  getChatHistory(username1: string, username2: string): Observable<Message[]> {
    return this.http.get<Message[]>(`${this.baseUrl}/History/${username1}/${username2}`).pipe(
      map((messages: Message[]) => {
        console.log('API Response:', messages);
        return messages.map(message => {
          message.timeStamp = new Date(message.timeStamp);
          return message;
        });
      })
    );
  }

  createChat(chat: Chat): Observable<Chat> {
    return this.http.post<Chat>(`${this.baseUrl}`, chat);
  }

  sendMessage(username: string, targetUsername: string, message: Message): Observable<void> {
    return this.getOrCreateChat(username, targetUsername).pipe(
      switchMap(chat => {
        chat.messages.push(message);
        return this.updateChat(chat.id, chat);
      }),
      catchError(this.handleError)
    );
  }

  private getOrCreateChat(username: string, targetUsername: string): Observable<Chat> {
    return this.http.get<Chat>(`${this.baseUrl}/Participants/${username}/${targetUsername}`).pipe(
      catchError(error => {
        if (error.status === 404) {
          const newChat: Chat = {
            id: new ObjectId().toHexString(),
            participants: [username, targetUsername],
            messages: []
          };
          return this.createChat(newChat);
        } else {
          return throwError(error);
        }
      })
    );
  }

  private updateChat(chatId: string, chat: Chat): Observable<void> {
    return this.http.put<void>(`${this.baseUrl}/${chatId}`, chat).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: any): Observable<never> {
    console.error('An error occurred', error);
    return throwError(error.message || error);
  }


  deleteChat(chatId: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${chatId}`);
  }

  deleteMessage(chatId: string, messageId: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${chatId}/Messages/${messageId}`);
  }

  getChatWithUser(username: string): Observable<Chat | null> {
    return this.http.get<Chat[]>(`${this.baseUrl}/User/${username}`).pipe(
      map(chats => chats.length > 0 ? chats[0] : null),
      catchError(error => {
        console.error('Error getting chat with user:', error);
        throw error;
      })
    );
  }

  getAllChatsForCurrentUser(username: string): Observable<Chat[]> {
    return this.http.get<Chat[]>(`${this.baseUrl}/User/$(username)`);
  }
}
